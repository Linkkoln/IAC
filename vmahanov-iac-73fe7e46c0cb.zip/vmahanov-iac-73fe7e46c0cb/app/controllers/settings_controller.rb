#!/bin/env ruby
# encoding: utf-8
class SettingsController < ApplicationController
  unloadable

  def plugin
  end
end
