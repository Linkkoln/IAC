module CartridgesHelper
end
