class CatalogContent < CiaDatabase
  self.table_name = "CATALOGCONTENT"
  self.primary_key = "contentid"
end