class Employee < ActiveRecord::Base
  unloadable
end
